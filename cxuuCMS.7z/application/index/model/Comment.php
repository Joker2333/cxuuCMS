<?php
/***
准备用来写文章内容的评论功能

 */
namespace app\index\model;

use think\Model;
class Comment extends Model {

    //protected $pk = 'id';

}

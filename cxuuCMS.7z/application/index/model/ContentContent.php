<?php
/**
 * Created by 龙啸轩PHP 信息 管理系统.
 * User: 邓中华
 * Date: 2018/11/1
 * Time: 11:32
 */
namespace app\index\model;

use think\Model;

class ContentContent extends Model {

    protected $pk = 'id';


}

<?php

return [
    \app\http\middleware\Check::class,
    'Check'
];

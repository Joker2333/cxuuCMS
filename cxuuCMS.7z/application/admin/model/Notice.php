<?php
/**
 * Created by 龙啸轩PHP 信息 管理系统.
 * User: 邓中华
 * Date: 2018/10/28
 * Time: 12:34
 */
namespace app\admin\model;

use think\Model;

class Notice extends Model {

    protected $pk = 'id';


}
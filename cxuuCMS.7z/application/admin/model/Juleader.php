<?php
/***
* 龙啸轩网站管理系统 作者：邓中华 20181009
***/
namespace app\admin\model;

use think\Model;

class Juleader extends Model {

    protected $pk = 'id';

}
